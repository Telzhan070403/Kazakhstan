from django.shortcuts import render, redirect
from .models import *
from .forms import NewsForm
from django.views.generic.detail import DetailView
from django.views.generic.edit import UpdateView, DeleteView


def home(request):
    return render(request, 'main/home.html')


def sut(request):
    return render(request, 'main/sutfood.html')

def flour(request):
    return render(request, 'main/flour.html')

def mens(request):
    return render(request, 'main/mens.html')

def sports(request):
    return render(request, 'main/sports.html')

def winter(request):
    sport = WinterSport.objects.all()
    return render(request, 'main/winter.html', {'sport': sport})

def summer(request):
    summer = SummerSport.objects.all()
    return render(request, 'main/Summer.html', {'summer': summer})

def womens(request):
    return render(request, 'main/womens.html')

def boots(request):
    return render(request, 'main/boots.html')


class NewsDeleteView(DeleteView):
    model = News
    success_url = '/news/'
    template_name = 'main/delete.html'


class NewsUpdateView(UpdateView):
    model = News
    template_name = 'main/update.html'
    form_class = NewsForm


class NewsDetailView(DetailView):
    model = News
    template_name = 'main/details_view.html'
    context_object_name = 'news'


def insert(request):
    error = ''
    if request.method == 'POST':
        form = NewsForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/news')
        else:
            error = 'Форма была неверной'

    form = NewsForm()
    data = {
        'form': form,
        'error': error
    }
    return render(request, 'main/insert.html', data)


def news(request):
    new = News.objects.order_by('-id')
    return render(request, 'main/news.html', {'news': new})
