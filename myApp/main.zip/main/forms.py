from .models import News
from django.forms import ModelForm, TextInput, Textarea

class NewsForm(ModelForm):
     class Meta:
        model = News
        fields = ['title', 'news']

        widgets ={
            "title": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Жаңалық атауы'
        }),
            "news": Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Жаңалықты енгізу'
            })
      }