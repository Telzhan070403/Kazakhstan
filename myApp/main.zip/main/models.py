from django.db import models


class News(models.Model):
     title = models.CharField('Названия', max_length=80)
     news = models.TextField('Описания', blank=False)

     def __str__(self):
         return self.title

     def get_absolute_url(self):
         return f'/news/{self.id}'


class SummerSport(models.Model):
        name = models.CharField(max_length=50)
        gold = models.IntegerField()
        silver = models.IntegerField()
        bronze = models.IntegerField()
        overall = models.IntegerField()

        def __str__(self):
            return self.name


class WinterSport(models.Model):
    name = models.CharField(max_length=50)
    gold = models.IntegerField()
    silver = models.IntegerField()
    bronze = models.IntegerField()
    overall = models.IntegerField()

    def __str__(self):
        return self.name


